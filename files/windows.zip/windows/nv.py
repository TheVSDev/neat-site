import os
import shutil
import tkinter as tk
from tkinter import filedialog
import time
from datetime import datetime
from plyer import notification
import hashlib



def clean_directory(path):
    num_files_deleted = 0
    num_dirs_deleted = 0
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Supprimer les fichiers temporaires et en cache
    for root, dirs, files in os.walk(path):
        for name in files:
            if name.endswith(('.tmp', '.cache')):
                file_path = os.path.join(root, name)
                file_size = os.path.getsize(file_path)
                os.remove(file_path)
                num_files_deleted += 1
                # Ajouter le fichier supprimé dans le journal
                journal_text.insert(tk.END, f"{current_time} : Supprimé le fichier '{file_path}', taille = {file_size} octets, raison = fichier temporaire ou en cache\n")
        for name in dirs:
            if name.endswith(('.tmp', '.cache')):
                dir_path = os.path.join(root, name)
                dir_size = shutil.disk_usage(dir_path).total
                shutil.rmtree(dir_path)
                num_dirs_deleted += 1
                # Ajouter le dossier supprimé dans le journal
                journal_text.insert(tk.END, f"{current_time} : Supprimé le dossier '{dir_path}', taille = {dir_size} octets, raison = dossier temporaire ou en cache\n")

    # Supprimer les fichiers et dossiers vides
    for root, dirs, files in os.walk(path, topdown=False):
        for name in dirs:
            dir_path = os.path.join(root, name)
            if not os.listdir(dir_path):
                dir_size = shutil.disk_usage(dir_path).total
                os.rmdir(dir_path)
                num_dirs_deleted += 1
                # Ajouter le dossier supprimé dans le journal
                journal_text.insert(tk.END, f"{current_time} : Supprimé le dossier '{dir_path}', taille = {dir_size} octets, raison = dossier vide\n")
        for name in files:
            file_path = os.path.join(root, name)
            if os.path.getsize(file_path) == 0:
                file_size = os.path.getsize(file_path)
                os.remove(file_path)
                num_files_deleted += 1
                # Ajouter le fichier supprimé dans le journal
                journal_text.insert(tk.END, f"{current_time} : Supprimé le fichier '{file_path}', taille = {file_size} octets, raison = fichier vide\n")

    # Dictionnaire pour stocker les hachages de chaque fichier
    hashes = {}

    # Parcourir tous les fichiers et dossiers dans le chemin donné
    for root, dirs, files in os.walk(path):
        for name in files + dirs:
            item_path = os.path.join(root, name)

            # Calculer le hachage du fichier ou dossier actuel
            if os.path.isfile(item_path):
                with open(item_path, "rb") as f:
                    file_hash = hashlib.sha256(f.read()).hexdigest()
            else:
                file_hash = hashlib.sha256(item_path.encode()).hexdigest()

            # Supprimer le fichier ou dossier si son hachage existe déjà dans le dictionnaire
            if file_hash in hashes:
                os.remove(item_path)
                journal_text.insert(tk.END, f"Supprimé le fichier/dossier '{item_path}' car il est en double.")
            else:
                hashes[file_hash] = item_path

    print("Suppression des doublons terminée avec succès.")








def browse_button():
    # Ouvrir une boîte de dialogue pour sélectionner le répertoire à nettoyer
    filename = filedialog.askdirectory()
    path.set(filename)





def clean_button():
    # Nettoyer le répertoire spécifié
    num_files_deleted, num_dirs_deleted = clean_directory(path.get())
   
    message = f"Le nettoyage est effectué. {num_files_deleted} fichiers et {num_dirs_deleted} dossiers ont été supprimés."
    output_label.config(text=message)

if __name__ == '__main__':
    # Créer une fenêtre tkinter pour la saisie du chemin d'accès et le nettoyage
    window = tk.Tk()
    window.title("Nettoyer un répertoire")

    # Ajouter un champ de saisie pour le chemin d'accès
    path = tk.StringVar()
    path_label = tk.Label(window, text="Chemin d'accès :")
    path_label.pack()
    path_entry = tk.Entry(window, textvariable=path)
    path_entry.pack()

    # Ajouter un bouton pour sélectionner le répertoire
    browse_button = tk.Button(window, text="Parcourir...", command=browse_button)
    browse_button.pack()

    # Ajouter un bouton pour nettoyer le répertoire
    clean_button = tk.Button(window, text="Nettoyer", command=clean_button)
    clean_button.pack()

    # Ajouter une étiquette pour afficher le résultat
    output_label = tk.Label(window, text="")
    output_label.pack()



    # Ajouter une zone de texte pour le journal
    journal_label = tk.Label(window, text="Journal de nettoyage :")
    journal_label.pack()
    journal_text = tk.Text(window, height=10)
    journal_text.pack()


def clear_journal():
    journal_text.delete('1.0', tk.END)

# Ajouter un bouton pour effacer le journal
clear_button = tk.Button(window, text="Effacer le journal", command=clear_journal)
clear_button.pack()

#Ajouter un bouton pour enregistrer le journal dans un fichier
def save_log():
    log = journal_text.get('1.0', tk.END)
    filename = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Fichiers texte", "*.txt")])
    if filename:
        with open(filename, 'w') as f:
            f.write(log)


save_button = tk.Button(window, text="Enregistrer le journal", command=save_log)
save_button.pack()



    # Démarrer la boucle principale tkinter
window.mainloop()


# Attente de 5 secondes avant la fin du script
time.sleep(5)
print("Le nettoyage est terminé.")

# Afficher une notification
notification.notify(
    title='Nettoyage terminé',
    message='Vous venez d\'effectuer un nettoyage sur votre répertoire.',
    app_name='Nettoyage',
    timeout=5
)