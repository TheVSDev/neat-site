import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from datetime import datetime
from windows import directories,test
import subprocess

# Créer une fenêtre
root = tk.Tk()
root.title("Journal de nettoyage")


def run_script():
    subprocess.run(["python", "C:/Users/33760/Desktop/nettoyage/windows.py"])

# Chemin absolu du fichier journal
journal_file = r"C:\Users\33760\Documents\journal.txt"


# Fonction pour vider le journal

def clear_journal():
    with open(journal_file, "w") as journal:
        journal.write("")
    text_journal.delete("1.0", tk.END)  # vider la zone de texte
    messagebox.showinfo("Journal vidé", "Le journal a été vidé avec succès.")

# Fonction pour enregistrer le journal dans un fichier texte
def save_journal():
    content = text_journal.get("1.0", tk.END)
    file_path = filedialog.asksaveasfilename(defaultextension=".txt")
    if file_path:
        with open(file_path, "w") as journal_file:
            journal_file.write(content)
        messagebox.showinfo("Journal enregistré", "Le journal a été enregistré avec succès.")


# Ajouter une étiquette pour le titre du journal
label_title = tk.Label(root, text="Journal de nettoyage", font=("Arial", 16))
label_title.pack(pady=20)

button_run_script = tk.Button(root, text="Exécuter",bg="#002B5B",fg="white", command=run_script)
button_run_script.pack(pady=10)


# Ajouter un bouton pour vider le journal
button_clear = tk.Button(root, text="Vider", bg="#57C5B6", fg="white", command=clear_journal)
button_clear.pack(pady=10)

# Ajouter un bouton pour enregistrer le journal
button_save = tk.Button(root, text="Enregistrer", bg="#159895", fg="white", command=save_journal)
button_save.pack(pady=10)

# Ajouter une zone de texte pour afficher le contenu du journal
text_journal = tk.Text(root, height=20, width=100)
text_journal.pack(pady=20)
# Créer une variable de contrôle pour la zone de texte
repertoire_var = tk.StringVar()
repertoire_var.set("Saisir un répertoire")

print(directories)



directories.append("hello")

print(directories)


# Fonction pour ajouter le répertoire saisi à la liste
def ajouter_repertoire():
    repertoire = repertoire_var.get()
    test()
    if repertoire not in directories:
        directories.append(repertoire)
        repertoire_var.set("Saisir un répertoire")
        print("Répertoire ajouté :", repertoire)
    else:
        print("Ce répertoire est déjà dans la liste :", repertoire)
        text_journal.delete("1.0", tk.END)
    with open(journal_file, "r") as journal:
        text_journal.insert(tk.END, journal.read())
    test()


# Fonction pour effacer le placeholder lorsque la zone de texte est cliquée
def effacer_placeholder(event):
    if repertoire_var.get() == "Saisir un répertoire":
        repertoire_var.set("")

# Ajouter une zone de texte pour saisir le répertoire
entry_repertoire = tk.Entry(root, textvariable=repertoire_var)
entry_repertoire.pack(pady=10)

# Ajouter un bouton pour ajouter le répertoire
button_ajouter = tk.Button(root, text="Ajouter", bg="#1A5F7A",fg="white", command=ajouter_repertoire)
button_ajouter.pack(pady=10)

# Effacer le placeholder lorsque la zone de texte est cliquée
entry_repertoire.bind("<Button-1>", effacer_placeholder)












# Lire le contenu du fichier journal et l'afficher dans la zone de texte
with open(journal_file, "r") as journal:
    text_journal.insert(tk.END, journal.read())

# Démarrer la boucle principale de l'interface graphique
root.mainloop()


